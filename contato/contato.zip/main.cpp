#include <iostream>
#include <string>
#include "centraldeajuda.h"
#include "contato.h"
#include "contatofinanceiro.h"


int main() {

	ContatoFianceiro *contaton = new ContatoFinanceiro(1, "INsta", "ufv.br",1);
	contaton->ExibirContato();



	return 0;
}